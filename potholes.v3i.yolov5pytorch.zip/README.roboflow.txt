
potholes - v3 2021-03-29 1:27pm
==============================

This dataset was exported via roboflow.ai on March 29, 2021 at 7:57 AM GMT

It includes 464 images.
Pothole are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


